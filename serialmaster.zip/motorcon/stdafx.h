#include <stdio.h>
#include <string.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <math.h>
#include <random>

#include <iostream>
#include <vector>
#include <iterator>

#include "my_functions.h"
#include "prnPrint.h"
#include "risPortableCalls.h"
